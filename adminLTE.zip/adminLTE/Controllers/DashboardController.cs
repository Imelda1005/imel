﻿using Microsoft.AspNetCore.Mvc;

namespace ProyekAdminLTE.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}