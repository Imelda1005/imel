﻿using Microsoft.AspNetCore.Mvc;

namespace adminLTE.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
