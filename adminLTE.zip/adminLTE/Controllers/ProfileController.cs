﻿using Microsoft.AspNetCore.Mvc;

namespace adminLTE.Controllers
{
    public class ProfileController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
