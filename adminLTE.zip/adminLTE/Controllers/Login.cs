﻿using Microsoft.AspNetCore.Mvc;

namespace adminLTE.Controllers
{
    public class Login : Controller
    {
        public IActionResult login()
        {
            return View();
        }
    }
}
